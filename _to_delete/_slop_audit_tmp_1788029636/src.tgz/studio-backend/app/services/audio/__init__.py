"""Audio provider service helpers."""
