"""Shared service-layer helpers."""
