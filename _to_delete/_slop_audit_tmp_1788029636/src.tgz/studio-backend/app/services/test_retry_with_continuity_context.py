"""
Tests for retry_with_continuity_context in RenderService.

Covers:
- Creates new job with retry_of set to original job_id
- Retry prompt includes fresh continuity context block
- retry_count increments correctly
- Maximum retry cap of 3 is enforced
- retry_advisory is set when cap is reached
- New job is NOT created when cap is reached
- retry_of and retry_advisory fields exist on RenderJobModel
- Endpoint returns correct response
"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.retry

from fastapi.testclient import TestClient
from main import app

from app.models import RenderJobModel
from app.services.render import RenderService
from conftest import run_async


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_failed_job(svc: RenderService, project_id: str = "film1", retry_count: int = 0) -> RenderJobModel:
    """Create a job and mark it failed."""
    job = svc.create_job(
        project_id=project_id,
        shot_id="scene_01_shot_001",
        provider="simulated",
        prompt="Wide establishing shot of the rain-soaked street.",
    )
    job.status = "failed"
    job.error_message = "Provider timeout"
    job.retry_count = retry_count
    svc._jobs[job.id] = job
    return job


def _client():
    return TestClient(app)


# ── 1. New job created with retry_of set ─────────────────────────────────────

class TestRetryCreatesNewJob:

    def test_creates_new_job_not_same_job(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        new_job_id = result["job"]["id"]
        assert new_job_id != job.id

    def test_new_job_has_retry_of_set(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["job"]["retry_of"] == job.id

    def test_new_job_has_same_shot_id(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["job"]["shot_id"] == job.shot_id

    def test_new_job_has_same_project_id(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["job"]["project_id"] == "film1"

    def test_result_has_advisory_key(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert "advisory" in result
        assert isinstance(result["advisory"], str)

    def test_result_has_capped_false_when_not_capped(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["capped"] is False

    def test_raises_for_unknown_job_id(self, render_service):
        svc = render_service
        import pytest
        with pytest.raises(ValueError, match="not found"):
            run_async(svc.retry_with_continuity_context("nonexistent-job", "film1", "scene_01"))


# ── 2. Retry prompt includes fresh context ────────────────────────────────────

class TestRetryPromptContent:

    def test_retry_note_appended_to_prompt(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        new_prompt = result["job"]["input_payload"]["prompt"]
        assert "[RETRY CONTEXT]" in new_prompt

    def test_retry_note_mentions_previous_attempt(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        new_prompt = result["job"]["input_payload"]["prompt"]
        assert "Previous attempt failed" in new_prompt

    def test_retry_note_mentions_visual_language(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        new_prompt = result["job"]["input_payload"]["prompt"]
        assert "visual language" in new_prompt.lower()

    def test_original_shot_description_preserved(self, render_service):
        svc = render_service
        job = _make_failed_job(svc)
        original_desc = "Wide establishing shot of the rain-soaked street."
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        new_prompt = result["job"]["input_payload"]["prompt"]
        assert original_desc in new_prompt

    def test_old_retry_context_not_duplicated(self, render_service):
        """If the original prompt already had a [RETRY CONTEXT] block, it should be stripped."""
        svc = render_service
        job = svc.create_job(
            project_id="film1",
            shot_id="scene_01_shot_001",
            provider="simulated",
            prompt="Shot description.\n\n[RETRY CONTEXT]\nOld retry note.",
        )
        job.status = "failed"
        job.retry_count = 1
        svc._jobs[job.id] = job
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        new_prompt = result["job"]["input_payload"]["prompt"]
        # Should only have one [RETRY CONTEXT] block
        assert new_prompt.count("[RETRY CONTEXT]") == 1

    def test_old_cinematic_context_stripped_before_fresh_one(self, render_service):
        """Old [CINEMATIC CONTEXT] block should be replaced, not duplicated."""
        svc = render_service
        job = svc.create_job(
            project_id="film1",
            shot_id="scene_01_shot_001",
            provider="simulated",
            prompt="Shot.\n\n[CINEMATIC CONTEXT]\nOld context.",
        )
        job.status = "failed"
        svc._jobs[job.id] = job
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        new_prompt = result["job"]["input_payload"]["prompt"]
        assert "Old context." not in new_prompt


# ── 3. retry_count increments ─────────────────────────────────────────────────

class TestRetryCountIncrements:

    def test_retry_count_is_1_on_first_retry(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=0)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["job"]["retry_count"] == 1

    def test_retry_count_is_2_on_second_retry(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=1)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["job"]["retry_count"] == 2

    def test_retry_count_is_3_on_third_retry(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=2)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["job"]["retry_count"] == 3

    def test_advisory_mentions_retry_number(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=0)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert "1 of 3" in result["advisory"]


# ── 4. Maximum retry cap ──────────────────────────────────────────────────────

class TestMaxRetryCap:

    def test_cap_enforced_at_3(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=3)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["capped"] is True

    def test_no_new_job_created_when_capped(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=3)
        job_count_before = len(svc._jobs)
        run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        # No new job should have been added
        assert len(svc._jobs) == job_count_before

    def test_capped_result_returns_original_job_id(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=3)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["job"]["id"] == job.id

    def test_retry_advisory_set_when_capped(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=3)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["job"]["retry_advisory"] is not None
        assert "Maximum retries" in result["job"]["retry_advisory"]

    def test_advisory_mentions_manual_review(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=3)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert "Manual review" in result["advisory"]

    def test_cap_also_enforced_above_3(self, render_service):
        svc = render_service
        job = _make_failed_job(svc, retry_count=5)
        result = run_async(svc.retry_with_continuity_context(job.id, "film1", "scene_01"))
        assert result["capped"] is True


# ── 5. Model fields ───────────────────────────────────────────────────────────

class TestModelFields:

    def test_retry_of_field_exists_and_defaults_none(self, render_service):
        job = RenderJobModel(id="j1", project_id="p1", shot_id="s1", provider="simulated")
        assert job.retry_of is None

    def test_retry_advisory_field_exists_and_defaults_none(self, render_service):
        job = RenderJobModel(id="j1", project_id="p1", shot_id="s1", provider="simulated")
        assert job.retry_advisory is None

    def test_retry_of_can_be_set(self, render_service):
        job = RenderJobModel(
            id="j2", project_id="p1", shot_id="s1", provider="simulated",
            retry_of="j1",
        )
        assert job.retry_of == "j1"

    def test_retry_advisory_can_be_set(self, render_service):
        job = RenderJobModel(
            id="j1", project_id="p1", shot_id="s1", provider="simulated",
            retry_advisory="Maximum retries reached. Manual review recommended.",
        )
        assert "Maximum retries" in job.retry_advisory


# ── 6. Endpoint integration ───────────────────────────────────────────────────

class TestRetryEndpoint:

    def _create_failed_job(self, client, project_id: str) -> str:
        """Create a project + failed job via the render service directly."""
        from app.services import render_service
        job = render_service.create_job(
            project_id=project_id,
            shot_id="scene_01_shot_001",
            provider="simulated",
            prompt="Test shot.",
        )
        job.status = "failed"
        job.error_message = "Test failure"
        render_service._jobs[job.id] = job
        return job.id

    def test_endpoint_returns_200(self, render_service):
        client = _client()
        created = client.post("/api/f51/studio/projects", json={"title": "Retry Test Film"})
        pid = created.json()["project_id"]
        job_id = self._create_failed_job(client, pid)

        resp = client.post(
            f"/api/f51/studio/projects/{pid}/render-jobs/{job_id}/retry",
        )
        assert resp.status_code == 200

    def test_endpoint_returns_required_keys(self, render_service):
        client = _client()
        created = client.post("/api/f51/studio/projects", json={"title": "Retry Keys Film"})
        pid = created.json()["project_id"]
        job_id = self._create_failed_job(client, pid)

        data = client.post(
            f"/api/f51/studio/projects/{pid}/render-jobs/{job_id}/retry",
        ).json()
        assert "job" in data
        assert "advisory" in data
        assert "capped" in data

    def test_endpoint_404_for_missing_project(self, render_service):
        client = _client()
        resp = client.post(
            "/api/f51/studio/projects/nonexistent/render-jobs/job-123/retry",
        )
        assert resp.status_code == 404

    def test_endpoint_404_for_missing_job(self, render_service):
        client = _client()
        created = client.post("/api/f51/studio/projects", json={"title": "Missing Job Film"})
        pid = created.json()["project_id"]
        resp = client.post(
            f"/api/f51/studio/projects/{pid}/render-jobs/nonexistent-job/retry",
        )
        assert resp.status_code == 404

    def test_endpoint_capped_response_when_max_retries(self, render_service):
        from app.services import render_service
        client = _client()
        created = client.post("/api/f51/studio/projects", json={"title": "Capped Film"})
        pid = created.json()["project_id"]

        job = render_service.create_job(
            project_id=pid,
            shot_id="scene_01_shot_001",
            provider="simulated",
            prompt="Test.",
        )
        job.status = "failed"
        job.retry_count = 3
        render_service._jobs[job.id] = job

        data = client.post(
            f"/api/f51/studio/projects/{pid}/render-jobs/{job.id}/retry",
        ).json()
        assert data["capped"] is True
        assert "Manual review" in data["advisory"]
